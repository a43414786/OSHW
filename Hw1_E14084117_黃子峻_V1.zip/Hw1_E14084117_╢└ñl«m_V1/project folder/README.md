# opencv-hw1

## enviroment
1. opencv-python 4.5.4-dev
2. matplotlib 3.1.1
3. pyqt5 5.15.6
4. torch 1.10.0
5. torchvision 0.11.1
6. python 3.7.11
7. torchsummary 1.5.1
8. numpy 1.21.4